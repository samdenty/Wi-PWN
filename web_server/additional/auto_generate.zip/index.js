var fs = require('fs'),
    $ = require('jQuery'),
    htmlMinify = require('html-minifier').minify,
    UglifyJS = require("uglify-js"),
    csso = require('csso'),
    replace = require("replace"),
    extension,
    data = '',
    file,
    combined,
    jsStatus,
    htmlStatus,
    JSresult;

console.log('Generating arrays...')
String.prototype.convertToHex = function(delim) {
    return this.split("").map(function(c) {
        return ("0" + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(delim || "");
}

function byte(file) {
    file = "0x" + file.convertToHex(",0x");
    combined = "const char data_" + filename + "_" + extension + "[] PROGMEM = {" + file + "};";
    return combined;
}
fs.readdir('html', function(err, items) {
    for (var i = 0; i < items.length; i++) {
        extension = items[i].split('.').pop().toUpperCase();
        filename = items[i].split('.')[0].toLowerCase();
        if (extension == "HTML") {
            file = fs.readFileSync('html/' + items[i], "utf8");
            file = htmlMinify(file, { collapseBooleanAttributes: !0, collapseWhitespace: !0, html5: !0, minifyCSS: !0, minifyJS: !0, processConditionalComments: !0, removeAttributeQuotes: !0, removeComments: !0, removeEmptyAttributes: !0, removeOptionalTags: !0, removeRedundantAttributes: !0, removeScriptTypeAttributes: !0, removeStyleLinkTypeAttributes: !0, removeTagWhitespace: !0, sortAttributes: !0, sortClassName: !0, trimCustomFragments: !0, useShortDoctype: !0 });
            data += byte(file) + '\n';
            console.log(items[i] + ' - complete!');
        } else if (extension == "CSS") {
            file = fs.readFileSync('html/' + items[i], "utf8");
            file = csso.minify(file).css;
            data += byte(file) + '\n';
            console.log(items[i] + ' - complete!');
        }
    }
    htmlStatus = true;
});
fs.readdir('html/js', function(err, items) {
    for (var i = 0; i < items.length; i++) {
        extension = items[i].split('.').pop().toUpperCase();
        filename = items[i].split('.')[0].toLowerCase();
        if (extension == "JS") {
            file = fs.readFileSync('html/js/' + items[i], "utf8");
            JSresult = UglifyJS.minify(file)
            data += byte(JSresult.code) + '\n';
            console.log(items[i] + ' - complete!');
        }
    }
    jsStatus = true;
});

var interval = setInterval(function() {
    if (htmlStatus == true && jsStatus == true) {
        clearInterval(interval);
        console.log('Replacing arrays...');
        data = "/*auto_generator*/\n" + data + "/*end_auto_generator*/";
        replace({
            regex: "\\\/\\*auto\\_generator\\*\\\/[\\s\\S]*\\\/\\*end\\_auto\\_generator\\*\\\/",
            replacement: data,
            paths: ['../arduino/Wi-PWN/data.h'],
            recursive: true,
            silent: true,
        });
        console.log('\x1b[32m', '\n-----------------------\nWrote arrays to data.h!', '\x1b[0m', '\n\nPress any key to exit');
        process.stdin.setRawMode(true);
        process.stdin.resume();
        process.stdin.on('data', process.exit.bind(process, 0));
    }
}, 1000);
